# PICKORA — GitHub + Vercel ready

PICKORA is a responsive React + Vite affiliate storefront with a manual product manager.

## Features
- Responsive storefront for mobile and desktop
- Indonesian / English language toggle
- Search and category filters
- Admin screen to add, edit, and delete products
- Manual product photo upload (JPG, PNG, WEBP; max 1.5 MB)
- Product name, price, description, category, and AliExpress affiliate URL
- Product image and Buy Now links open the saved affiliate URL
- Import/export product catalog as JSON

## Run locally
1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown in the terminal.

## Publish with GitHub and Vercel
1. Create a new GitHub repository, for example `pickora-store`.
2. Upload all files and folders from this project to the repository.
3. In Vercel, choose **Add New → Project**, import the GitHub repository.
4. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
5. Click **Deploy**.

## Important: how product publishing works in this starter
This starter deliberately does not use Supabase, a database, or AliExpress API.

- Products in `public/catalog.json` are the public catalog that every visitor sees.
- The Admin screen saves edits in that browser's local storage. This is useful for preparing products, but it does NOT sync changes to other visitors.
- To publish products for everyone: open Admin → add/edit products → click **Export catalog JSON**. Replace `public/catalog.json` in the GitHub repository with the exported file (same filename), commit the change, and Vercel will redeploy automatically.
- To continue editing on another device, use **Import catalog JSON** to load the latest catalog first.
- Uploaded images are embedded in the JSON as data URLs. Keep images optimized and under 1.5 MB each. For a large catalog (100+ products), use compressed images and consider moving images to a public image host later.

## Affiliate links
Enter the full affiliate URL for each product, such as an AliExpress `s.click.aliexpress.com` URL. The product image and **Buy Now** button both open that saved URL in a new tab. Use your own affiliate links and comply with the affiliate program's disclosure rules.

## Before public launch
- Add your affiliate disclosure and contact / privacy pages if needed.
- Test every affiliate URL.
- Test the site on a phone.
- Do not enter real customer payment details; PICKORA is a product discovery / affiliate storefront, not a checkout system.
