import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Search, ShoppingBag, Globe2, SlidersHorizontal, ArrowUpRight, Plus,
  Pencil, Trash2, Upload, X, LayoutDashboard, Store, Download, UploadCloud,
  ExternalLink, Package, ImagePlus, Check, Menu
} from 'lucide-react'
import './style.css'

const STORAGE_KEY = 'pickora-products-v1'
const money = (value, lang) => {
  if (!value) return lang === 'id' ? 'Cek harga terbaru' : 'Check latest price'
  const raw = String(value).trim()
  if (/[a-zA-Z$€£¥]/.test(raw)) return raw
  const n = Number(raw.replace(/[^\d.,]/g, '').replace(/\./g, '').replace(',', '.'))
  if (!Number.isFinite(n)) return raw
  return new Intl.NumberFormat(lang === 'id' ? 'id-ID' : 'en-US', {
    style: 'currency', currency: 'USD', maximumFractionDigits: 2
  }).format(n)
}

const copy = {
  id: {
    discover: 'Temukan produk pilihan untuk keseharianmu.',
    subtitle: 'Pilihan menarik, dikurasi untuk kamu.',
    search: 'Cari produk...',
    all: 'Semua',
    shop: 'Lihat produk',
    featured: 'Pilihan untuk kamu',
    explore: 'Jelajahi koleksi',
    products: 'produk',
    empty: 'Belum ada produk di katalog.',
    emptySearch: 'Produk tidak ditemukan.',
    admin: 'Admin',
    add: 'Tambah produk',
    edit: 'Edit produk',
    name: 'Nama produk',
    price: 'Harga',
    category: 'Kategori',
    description: 'Deskripsi',
    affiliate: 'Link affiliate AliExpress',
    image: 'Foto produk',
    upload: 'Unggah foto',
    save: 'Simpan produk',
    cancel: 'Batal',
    required: 'Isi nama produk dan link affiliate terlebih dahulu.',
    saved: 'Produk tersimpan di browser ini.',
    publicNote: 'Agar perubahan tampil untuk semua pengunjung, ekspor katalog lalu unggah file catalog.json ke GitHub dan deploy ulang.',
    export: 'Ekspor katalog JSON',
    import: 'Impor katalog JSON',
    manage: 'Kelola katalog',
    noImage: 'Foto produk',
    visit: 'Beli di AliExpress',
    deleteConfirm: 'Hapus produk ini?',
    footer: 'Temukan produk menarik dari berbagai kategori.',
    language: 'English',
    adminHint: 'Perubahan saat ini tersimpan di browser admin ini, belum otomatis tersinkron ke semua pengunjung.',
    count: 'Total produk',
    close: 'Tutup'
  },
  en: {
    discover: 'Discover thoughtful finds for everyday life.',
    subtitle: 'Interesting picks, curated for you.',
    search: 'Search products...',
    all: 'All',
    shop: 'Explore products',
    featured: 'Picks for you',
    explore: 'Explore the collection',
    products: 'products',
    empty: 'There are no products in the catalog yet.',
    emptySearch: 'No products found.',
    admin: 'Admin',
    add: 'Add product',
    edit: 'Edit product',
    name: 'Product name',
    price: 'Price',
    category: 'Category',
    description: 'Description',
    affiliate: 'AliExpress affiliate link',
    image: 'Product image',
    upload: 'Upload image',
    save: 'Save product',
    cancel: 'Cancel',
    required: 'Please enter a product name and affiliate link.',
    saved: 'Product saved in this browser.',
    publicNote: 'To publish changes for all visitors, export the catalog, upload catalog.json to GitHub, and redeploy.',
    export: 'Export catalog JSON',
    import: 'Import catalog JSON',
    manage: 'Manage catalog',
    noImage: 'Product image',
    visit: 'Shop on AliExpress',
    deleteConfirm: 'Delete this product?',
    footer: 'Discover interesting products across categories.',
    language: 'Indonesia',
    adminHint: 'Changes are currently saved in this admin browser and are not automatically synced to all visitors.',
    count: 'Products',
    close: 'Close'
  }
}

function App() {
  const [lang, setLang] = useState('en')
  const t = copy[lang]
  const [products, setProducts] = useState([])
  const [loaded, setLoaded] = useState(false)
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [admin, setAdmin] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({ name:'', price:'', category:'General', description:'', affiliateUrl:'', image:'' })
  const [notice, setNotice] = useState('')

  useEffect(() => {
    let active = true
    fetch('/catalog.json')
      .then(r => r.ok ? r.json() : [])
      .then(seed => {
        if (!active) return
        let local = null
        try { local = localStorage.getItem(STORAGE_KEY) } catch {}
        setProducts(local ? JSON.parse(local) : (Array.isArray(seed) ? seed : []))
        setLoaded(true)
      })
      .catch(() => {
        try { setProducts(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')) }
        catch { setProducts([]) }
        setLoaded(true)
      })
    return () => { active = false }
  }, [])

  useEffect(() => {
    if (!loaded) return
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(products)) } catch {
      setNotice('Storage is full. Export your catalog and use smaller images.')
    }
  }, [products, loaded])

  const categories = useMemo(() => ['all', ...new Set(products.map(p => p.category).filter(Boolean))], [products])
  const visible = useMemo(() => products.filter(p => {
    const matchesCategory = category === 'all' || p.category === category
    const haystack = `${p.name} ${p.description} ${p.category}`.toLowerCase()
    return matchesCategory && haystack.includes(query.toLowerCase())
  }), [products, category, query])

  const openNew = () => {
    setEditing('new')
    setForm({ name:'', price:'', category:'General', description:'', affiliateUrl:'', image:'' })
  }
  const openEdit = p => {
    setEditing(p.id)
    setForm({ name:p.name || '', price:p.price || '', category:p.category || 'General', description:p.description || '', affiliateUrl:p.affiliateUrl || '', image:p.image || '' })
  }
  const saveProduct = e => {
    e.preventDefault()
    if (!form.name.trim() || !form.affiliateUrl.trim()) {
      setNotice(t.required); return
    }
    try { new URL(form.affiliateUrl) } catch { setNotice('Masukkan URL affiliate yang valid.'); return }
    if (editing === 'new') {
      setProducts(prev => [{ ...form, id: crypto.randomUUID(), createdAt: new Date().toISOString() }, ...prev])
    } else {
      setProducts(prev => prev.map(p => p.id === editing ? { ...p, ...form } : p))
    }
    setEditing(null)
    setNotice(t.saved)
    setTimeout(() => setNotice(''), 3500)
  }
  const removeProduct = id => {
    if (window.confirm(t.deleteConfirm)) setProducts(prev => prev.filter(p => p.id !== id))
  }
  const uploadImage = e => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) { setNotice('File harus berupa gambar.'); return }
    if (file.size > 1.5 * 1024 * 1024) { setNotice('Ukuran gambar maksimal 1.5 MB. Kompres foto sebelum mengunggah.'); return }
    const reader = new FileReader()
    reader.onload = () => setForm(prev => ({ ...prev, image: reader.result }))
    reader.readAsDataURL(file)
  }
  const exportCatalog = () => {
    const blob = new Blob([JSON.stringify(products, null, 2)], { type:'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'catalog.json'; a.click()
    URL.revokeObjectURL(url)
  }
  const importCatalog = e => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result)
        if (!Array.isArray(data)) throw new Error()
        setProducts(data); setNotice('Catalog imported successfully.')
      } catch { setNotice('File catalog.json tidak valid.') }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={() => {setAdmin(false);setCategory('all')}}>
        <span className="brand-mark">P</span><span>PICKORA<span className="brand-dot">.</span></span>
      </a>
      <nav className={`nav-links ${mobileMenu ? 'show' : ''}`}>
        <a href="#collection" onClick={() => setAdmin(false)}>{lang === 'id' ? 'Koleksi' : 'Collection'}</a>
        <a href="#about">{lang === 'id' ? 'Tentang' : 'About'}</a>
      </nav>
      <div className="top-actions">
        <button className="icon-btn language-btn" onClick={() => setLang(lang === 'id' ? 'en' : 'id')} aria-label="Change language"><Globe2 size={17}/><span>{lang.toUpperCase()}</span></button>
        <button className="admin-trigger" onClick={() => setAdmin(!admin)}><LayoutDashboard size={16}/>{t.admin}</button>
        <button className="icon-btn mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)}><Menu/></button>
      </div>
    </header>

    {admin ? <main className="admin-wrap">
      <div className="admin-heading">
        <div><span className="eyebrow">PICKORA / BACK OFFICE</span><h1>{t.manage}</h1><p>{t.adminHint}</p></div>
        <button className="dark-btn" onClick={() => setAdmin(false)}><Store size={17}/> {lang === 'id' ? 'Lihat toko' : 'View store'}</button>
      </div>
      <div className="admin-stats">
        <div className="stat-card"><span>{t.count}</span><strong>{products.length}</strong></div>
        <div className="stat-card"><span>{lang === 'id' ? 'Kategori' : 'Categories'}</span><strong>{Math.max(0,categories.length-1)}</strong></div>
        <div className="stat-card"><span>{lang === 'id' ? 'Status' : 'Status'}</span><strong className="status-ready">● {lang === 'id' ? 'Siap dikelola' : 'Ready'}</strong></div>
      </div>
      <div className="admin-toolbar">
        <h2>{lang === 'id' ? 'Daftar produk' : 'Product list'}</h2>
        <div className="toolbar-actions">
          <label className="outline-btn"><UploadCloud size={16}/>{t.import}<input type="file" accept="application/json" hidden onChange={importCatalog}/></label>
          <button className="outline-btn" onClick={exportCatalog}><Download size={16}/>{t.export}</button>
          <button className="primary-btn" onClick={openNew}><Plus size={17}/>{t.add}</button>
        </div>
      </div>
      <div className="admin-list">
        {products.length === 0 ? <div className="admin-empty"><Package size={34}/><p>{t.empty}</p><button className="primary-btn" onClick={openNew}><Plus size={16}/>{t.add}</button></div> :
          products.map(p => <div className="admin-row" key={p.id}>
            <div className="admin-product-image">{p.image ? <img src={p.image} alt={p.name}/> : <ImagePlus/>}</div>
            <div className="admin-product-info"><strong>{p.name}</strong><span>{p.category} · {p.price || '—'}</span></div>
            <div className="admin-row-actions"><button className="icon-btn" onClick={() => openEdit(p)} aria-label="Edit"><Pencil size={17}/></button><button className="icon-btn danger" onClick={() => removeProduct(p.id)} aria-label="Delete"><Trash2 size={17}/></button></div>
          </div>)
        }
      </div>
      <div className="publish-note"><strong>Catatan publikasi</strong><p>{t.publicNote}</p></div>
    </main> : <>
      <section className="hero">
        <div className="hero-copy"><span className="eyebrow">A LITTLE DISCOVERY GOES A LONG WAY</span><h1>Find your<br/><em>next favorite.</em></h1><p>{t.discover} {t.subtitle}</p><a className="hero-cta" href="#collection">{t.shop}<ArrowUpRight size={17}/></a></div>
        <div className="hero-art">
          <div className="hero-orbit orbit-one"></div><div className="hero-orbit orbit-two"></div>
          <div className="hero-card card-back"><span>CURATED FINDS</span><div className="abstract-shape"></div></div>
          <div className="hero-card card-front"><div className="mini-label">PICKORA SELECT</div><div className="hero-sun"></div><div className="hero-lines"></div><span>GOOD THINGS<br/>LIVE HERE.</span></div>
          <div className="floating-tag"><span className="tag-dot"></span> DISCOVER MORE</div>
        </div>
      </section>
      <main id="collection" className="collection">
        <div className="section-head"><div><span className="eyebrow">THE PICKORA EDIT</span><h2>{t.featured}</h2><p>{t.explore}</p></div><div className="product-count">{products.length.toString().padStart(2,'0')} <span>{t.products}</span></div></div>
        <div className="catalog-controls">
          <div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder={t.search}/></div>
          <div className="category-list"><SlidersHorizontal size={16}/>{categories.map(c => <button key={c} className={category===c?'active':''} onClick={() => setCategory(c)}>{c==='all'?t.all:c}</button>)}</div>
        </div>
        {!loaded ? <div className="loading-state">Loading collection...</div> :
          visible.length === 0 ? <div className="empty-state"><ShoppingBag size={32}/><p>{products.length ? t.emptySearch : t.empty}</p>{admin ? <button className="primary-btn" onClick={openNew}>{t.add}</button> : null}</div> :
          <div className="product-grid">{visible.map(p => <article className="product-card" key={p.id}>
            <a className="product-image" href={p.affiliateUrl} target="_blank" rel="sponsored nofollow noopener noreferrer" aria-label={`${t.visit}: ${p.name}`}>
              {p.image ? <img src={p.image} alt={p.name}/> : <div className="image-placeholder"><ImagePlus size={34}/><span>{t.noImage}</span></div>}
              <span className="image-arrow"><ArrowUpRight size={18}/></span>
            </a>
            <div className="product-meta"><span>{p.category || 'PICKORA'}</span><span className="price">{money(p.price,lang)}</span></div>
            <h3>{p.name}</h3><p className="product-description">{p.description || ''}</p>
            <a className="buy-link" href={p.affiliateUrl} target="_blank" rel="sponsored nofollow noopener noreferrer">{t.visit}<ArrowUpRight size={16}/></a>
          </article>)}</div>
        }
      </main>
      <section id="about" className="about-strip"><div><span className="eyebrow">PICKORA</span><h2>Good finds.<br/><em>One click away.</em></h2></div><p>{t.footer}</p></section>
      <footer className="footer"><a className="brand" href="#"><span className="brand-mark">P</span><span>PICKORA<span className="brand-dot">.</span></span></a><span>© {new Date().getFullYear()} PICKORA. {lang==='id'?'Hak cipta dilindungi.':'All rights reserved.'}</span><span className="footer-note">Affiliate links may earn us a commission.</span></footer>
    </>}

    {editing !== null && <div className="modal-backdrop" onMouseDown={e => {if(e.target===e.currentTarget)setEditing(null)}}>
      <form className="product-modal" onSubmit={saveProduct}>
        <div className="modal-head"><div><span className="eyebrow">PRODUCT DETAILS</span><h2>{editing==='new'?t.add:t.edit}</h2></div><button type="button" className="icon-btn" onClick={() => setEditing(null)}><X/></button></div>
        <label className="field-label">{t.name}<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Minimal Desk Lamp"/></label>
        <div className="form-two"><label className="field-label">{t.price}<input value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="e.g. $19.90"/></label><label className="field-label">{t.category}<input value={form.category} onChange={e=>setForm({...form,category:e.target.value})} placeholder="Home, Tech, Fashion..."/></label></div>
        <label className="field-label">{t.description}<textarea rows="3" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Short product description..."/></label>
        <label className="field-label">{t.affiliate}<input required type="url" value={form.affiliateUrl} onChange={e=>setForm({...form,affiliateUrl:e.target.value})} placeholder="https://s.click.aliexpress.com/..."/></label>
        <div className="field-label">{t.image}<label className="image-upload">{form.image ? <img src={form.image} alt="Preview"/> : <><Upload size={20}/><span>{t.upload}</span><small>JPG, PNG, WEBP · max 1.5 MB</small></>}<input type="file" accept="image/*" hidden onChange={uploadImage}/></label></div>
        <div className="modal-actions"><button type="button" className="outline-btn" onClick={() => setEditing(null)}>{t.cancel}</button><button className="primary-btn" type="submit"><Check size={17}/>{t.save}</button></div>
      </form>
    </div>}
    {notice && <div className="toast"><Check size={16}/>{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
  </div>
}

createRoot(document.getElementById('root')).render(<App/>)
